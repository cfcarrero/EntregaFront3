//Este componente deberia recibir por props y mostrar en pantalla la informacion
//que envia el usuario

import { useState } from "react";

export const Card = () => {
  const [artista,setArtista] = useState('');
  const [cancion,setCancion] = useState('');
  const [lanzamiento,setLanzamiento] = useState(0);
  
    function handlerSubmit (e) {
      e.preventDefault()
      if(artista <3&&artista.includes(' ')){
        console.log("Por favor chequea que la información sea correcta")
      } else if(cancion <6){
        console.log("Por favor chequea que la información sea correcta")
      }

  return (
    <>
    <form onSubmit={handlerSubmit}>
    <div>
      <label htmlFor="Artista">Artista</label>
        <input type="text" name="Artista" value={artista}
        onChange={e =>setArtista(e.target.value)}></input>
    </div>

    <button>
        Enviar
      </button>
    </form>
    </>
  );
  }
}