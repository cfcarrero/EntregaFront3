import React, { useState } from "react";


function App() {
  //Aqui deberias agregar los estados y los handlers para los inputs
  return (
    <div className="App">
      <h1>Elige un color</h1>
        <label>Artista</label>
        <input
          value={artista}
          onChange={set}
        />

        <input type="submit"/>
        <Card/>
    </div>
    
  );
}


export default App;
